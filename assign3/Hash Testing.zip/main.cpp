#include<vector>
#include<iostream>
#include<fstream>
#include<chrono>

using namespace std;
#define M 65537

int hash_(std::string id){
    // IMPLEMENT YOUR CODE HERE

     // Placeholder return value
}

int main(){

    ifstream f;
    f.open("test_ids.txt");
    string id;
    vector<bool> reached(M,false);
    int cols=0;
    // auto start = chrono::high_resolution_clock::now();
    while(f>>id){
        int i = hash_(id);
        int c=0;
        while(reached[(i+c*c*c)%M]){
            cols++;
            c++;
        }
        reached[(i+c*c*c)%M]=true;
    }
    f.close();
        // auto end=chrono::high_resolution_clock::now();
        // auto time = chrono::duration_cast<chrono::microseconds>(end-start);
        // cout<<flush<<"Prime: "<<p<<endl<<"Collisions: "<<cols<<endl<<"Time: "<<time.count();}
    cout<<cols<<endl;

    
    return 0;
}
